-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 02, 2026 at 03:18 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tuitionbooking`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` int UNSIGNED NOT NULL,
  `transaction` char(36) NOT NULL,
  `type` varchar(7) NOT NULL,
  `primary_key` int UNSIGNED DEFAULT NULL,
  `source` varchar(255) NOT NULL,
  `parent_source` varchar(255) DEFAULT NULL,
  `original` mediumtext,
  `changed` mediumtext,
  `meta` mediumtext,
  `status` int NOT NULL DEFAULT '1',
  `slug` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `transaction`, `type`, `primary_key`, `source`, `parent_source`, `original`, `changed`, `meta`, `status`, `slug`, `created`) VALUES
(1, '1de06515-641d-42c9-a1c7-c3087d356d45', 'create', 1, 'tutors', NULL, '[]', '{\"id\":1,\"name\":\"NURFATIHAH ASYIRA\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone\":\"0176019723\",\"subject\":\"Islamic Studies\",\"availability\":\"1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-01-10 23:07:00'),
(2, '1e1223f8-7d4c-40e3-8ac8-966672021d7e', 'create', 2, 'tutors', NULL, '[]', '{\"id\":2,\"name\":\"NURFATIHAH ASYIRA\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone\":\"0176019723\",\"subject\":\"Principles of Accounting\",\"availability\":\"1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-01-10 23:16:18'),
(3, '1d0de08d-c1da-4890-b06e-65becfb7aefa', 'create', 3, 'tutors', NULL, '[]', '{\"id\":3,\"name\":\"NURFATIHAH ASYIRA\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone\":\"0176019723\",\"subject\":\"Additional Mathematics\",\"availability\":\"1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-01-10 23:20:49'),
(4, '6da6f0dc-c624-4f37-a497-fc18d3ff8aca', 'create', 1, 'students', NULL, '[]', '{\"id\":1,\"name\":\"NURFATIHAH ASYIRA\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone_number\":\"0176019723\",\"address\":\"U10\\/ Pulau Angsa\\r\\nJalan Mokhtar Dahari\",\"birth_date\":\"2026-01-09\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/students\\/add\",\"slug\":1}', 1, NULL, '2026-01-10 23:25:17'),
(5, 'd7f3b073-c9e3-4a19-8fff-fa01d93adeac', 'create', 1, 'subjects', NULL, '[]', '{\"id\":1,\"name\":\"Mathematics\",\"level\":\"Primary 1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/subjects\\/add\",\"slug\":1}', 1, NULL, '2026-01-10 23:36:34'),
(6, 'ba2b1063-2060-46b9-859f-07ce42aaeb9c', 'create', 2, 'subjects', NULL, '[]', '{\"id\":2,\"name\":\"Bahasa Melayu\",\"level\":\"Primary 1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/subjects\\/add\",\"slug\":1}', 1, NULL, '2026-01-10 23:47:25'),
(7, '8b1c018c-f009-49d2-a5d3-f5434838c446', 'create', 3, 'subjects', NULL, '[]', '{\"id\":3,\"name\":\"History\",\"level\":\"Primary 3\",\"status\":0}', '{\"a_name\":\"Add\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/subjects\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 00:03:42'),
(8, '41ffba87-89b4-4cc3-9e8f-d879c2ed2898', 'delete', 3, 'subjects', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/subjects\\/delete\\/3\",\"slug\":1}', 1, NULL, '2026-01-11 00:06:40'),
(9, '78d5fbe8-ab11-4914-8ac8-e1bec6fd61e0', 'create', 4, 'subjects', NULL, '[]', '{\"id\":4,\"name\":\"Bahasa Melayu\",\"level\":\"Primary 1\",\"status\":3}', '{\"a_name\":\"Add\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/subjects\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 00:06:51'),
(10, '4e473ddc-fb4b-425f-98b3-4899d4e19449', 'update', 4, 'subjects', NULL, '{\"status\":3}', '{\"status\":4}', '{\"a_name\":\"Edit\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/subjects\\/edit\\/4\",\"slug\":1}', 1, NULL, '2026-01-11 00:11:42'),
(11, 'ef9ca588-5417-45c7-8335-0d61d2ff1192', 'create', 4, 'tutors', NULL, '[]', '{\"id\":4,\"name\":\"NURFATIHAH ASYIRA\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone\":\"0176019723\",\"subject\":\"Additional Mathematics\",\"availability\":\"1\"}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 03:58:53'),
(12, '368911b7-9138-421d-b0f4-bf079b63b26b', 'create', 5, 'subjects', NULL, '[]', '{\"id\":5,\"name\":\"Bahasa Melayu\",\"level\":\"Form 1\",\"status\":3}', '{\"a_name\":\"Add\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/subjects\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 04:28:23'),
(13, '280aa1aa-cbd2-45c6-8605-b3f0e4afbfe2', 'update', 4, 'subjects', NULL, '{\"status\":4}', '{\"status\":2}', '{\"a_name\":\"Edit\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/subjects\\/edit\\/4\",\"slug\":1}', 1, NULL, '2026-01-11 04:28:48'),
(14, 'ce55a85a-f4d4-4010-a33b-5be900d3fab4', 'update', 5, 'subjects', NULL, '{\"status\":3}', '{\"status\":1}', '{\"a_name\":\"Edit\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/subjects\\/edit\\/5\",\"slug\":1}', 1, NULL, '2026-01-11 04:32:38'),
(15, '571d67cb-411d-4d6b-80fd-403249c44d95', 'create', 5, 'tutors', NULL, '[]', '{\"id\":5,\"name\":\"NURFATIHAH ASYIRA\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone\":\"0176019723\",\"subject\":\"Music\",\"availability\":\"0\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 04:43:03'),
(16, 'f1ecd6d7-4a7d-4e0f-8e72-8299431d267b', 'create', 6, 'tutors', NULL, '[]', '{\"id\":6,\"name\":\"NURFATIHAH ASYIRA\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone\":\"0176019723\",\"subject\":\"Computer Science\",\"availability\":\"0\",\"status\":0}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 04:45:36'),
(17, '1a8a456c-a5b6-493d-b080-d5eaf762abbb', 'create', 6, 'subjects', NULL, '[]', '{\"id\":6,\"name\":\"Bahasa Melayu\",\"level\":\"Primary 1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/subjects\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 13:27:16'),
(18, '7dbd7ff2-ccce-4cba-a118-7d6552c81c06', 'create', 7, 'tutors', NULL, '[]', '{\"id\":7,\"name\":\"NURFATIHAH ASYIRA\",\"email\":\"misyamatcha@gmail.com\",\"phone\":\"0176019723\",\"subject\":\"Principles of Accounting\",\"availability\":\"1\",\"status\":0}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 16:30:32'),
(19, 'ccb83136-941d-4156-bc9f-46914b30bac8', 'create', 1, 'teams', NULL, '[]', '{\"id\":1,\"subject_name\":\"Bahasa Melayu\",\"tutor_name\":\"Class A1\",\"start_time\":\"2026-01-06T18:50:38+08:00\",\"end_time\":\"2026-01-07T18:50:41+08:00\",\"total_student\":5,\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/teams\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 18:50:47'),
(20, '012bd574-25ce-4c8b-9f74-0f22b06ac2b0', 'create', 2, 'teams', NULL, '[]', '{\"id\":2,\"subject_name\":\"Bahasa Melayu\",\"tutor_name\":\"Class A1\",\"start_time\":\"2026-01-02T18:53:18+08:00\",\"end_time\":\"2026-01-11T18:54:22+08:00\",\"total_student\":4,\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/teams\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 18:53:28'),
(21, '6357903b-890c-40bd-8b09-001c99ad0f38', 'create', 1, 'bookings', NULL, '[]', '{\"id\":1,\"student_name\":\"misha\",\"class_name\":\"Class A1\",\"date\":\"2025-12-29T19:17:33+08:00\",\"status\":\"1\"}', '{\"a_name\":\"Add\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 19:17:39'),
(22, '30313e35-ddfc-46e6-9a39-436cc695b493', 'delete', 1, 'teams', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/teams\\/delete\\/1\",\"slug\":1}', 1, NULL, '2026-01-11 22:18:20'),
(23, 'd3017df3-27f0-409e-9b4e-9e129f822efb', 'delete', 2, 'teams', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/teams\\/delete\\/2\",\"slug\":1}', 1, NULL, '2026-01-11 22:18:22'),
(24, '9acab606-1f53-4557-9d6f-de3a91dfd506', 'delete', 1, 'students', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/students\\/delete\\/1\",\"slug\":1}', 1, NULL, '2026-01-11 22:18:36'),
(25, '9bf2463e-bc94-4dbf-903a-f99c0cbf1eb4', 'delete', 1, 'subjects', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/subjects\\/delete\\/1\",\"slug\":1}', 1, NULL, '2026-01-11 22:18:41'),
(26, 'ae022dcc-1b67-4649-a731-f0f357ea5889', 'delete', 2, 'subjects', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/subjects\\/delete\\/2\",\"slug\":1}', 1, NULL, '2026-01-11 22:18:44'),
(27, '752ac55c-12a3-4b2f-95ab-412f8c10ddca', 'delete', 4, 'subjects', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/subjects\\/delete\\/4\",\"slug\":1}', 1, NULL, '2026-01-11 22:18:46'),
(28, '0e56ffc5-c098-40fc-97c4-5692da3ca5fe', 'delete', 5, 'subjects', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/subjects\\/delete\\/5\",\"slug\":1}', 1, NULL, '2026-01-11 22:18:49'),
(29, 'a352f1e6-3b31-4e1a-bc9b-d6987f0a4868', 'delete', 6, 'subjects', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/subjects\\/delete\\/6\",\"slug\":1}', 1, NULL, '2026-01-11 22:19:07'),
(30, '1dc121fc-7887-4b79-8ad9-a7a8f0838770', 'delete', 1, 'tutors', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/delete\\/1\",\"slug\":1}', 1, NULL, '2026-01-11 22:19:18'),
(31, 'f11892f3-fc1c-4201-be81-87a7f309bfac', 'delete', 2, 'tutors', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/delete\\/2\",\"slug\":1}', 1, NULL, '2026-01-11 22:19:21'),
(32, '1a4265c8-5c3f-4fab-b5ab-5d2ce456fd84', 'delete', 3, 'tutors', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/delete\\/3\",\"slug\":1}', 1, NULL, '2026-01-11 22:19:24'),
(33, 'cb7f1525-9c65-4f48-b497-e5bd1028d830', 'delete', 4, 'tutors', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/delete\\/4\",\"slug\":1}', 1, NULL, '2026-01-11 22:19:27'),
(34, 'a9861d83-6326-4b11-979a-eafeeae520b8', 'delete', 5, 'tutors', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/delete\\/5\",\"slug\":1}', 1, NULL, '2026-01-11 22:19:30'),
(35, '147b7320-531a-4467-ba2c-e68cb1f0d357', 'delete', 6, 'tutors', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/delete\\/6\",\"slug\":1}', 1, NULL, '2026-01-11 22:19:32'),
(36, '6eae49de-b9a5-47bc-8ef2-8a64cae3aef9', 'delete', 7, 'tutors', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/delete\\/7\",\"slug\":1}', 1, NULL, '2026-01-11 22:19:35'),
(37, 'daeb4522-adc8-4d9a-ab16-eea5434957a4', 'create', 3, 'teams', NULL, '[]', '{\"id\":3,\"subject_name\":\"Bahasa Melayu\",\"tutor_name\":\"Class A1\",\"start_time\":\"2026-01-11T22:25:41+08:00\",\"end_time\":\"2026-01-11T22:25:45+08:00\",\"total_student\":30,\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/teams\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 22:26:00'),
(38, '0e4d3162-46f9-4d86-aa8e-2d30a91ba36c', 'create', 2, 'students', NULL, '[]', '{\"id\":2,\"name\":\"NURFATIHAH ASYIRA\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone_number\":\"0176019723\",\"address\":\"U10\\/ Pulau Angsa\\r\\nJalan Mokhtar Dahari\",\"birth_date\":\"2025-12-29\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/students\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 22:29:21'),
(39, '1e0f51f8-8101-4054-8140-1d4d02b9e35e', 'create', 4, 'teams', NULL, '[]', '{\"id\":4,\"subject_name\":\"Bahasa Melayu\",\"tutor_name\":\"Class A1\",\"start_time\":\"2025-12-30T22:30:30+08:00\",\"end_time\":\"2026-01-11T22:30:33+08:00\",\"total_student\":22,\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/teams\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 22:30:41'),
(40, 'dd709fed-7288-45fa-9a3a-503b33cae0a5', 'create', 7, 'subjects', NULL, '[]', '{\"id\":7,\"name\":\"English\",\"level\":\"Primary 1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/subjects\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 22:42:06'),
(41, 'f27014bd-1834-42f3-9c63-afa9772e3f7b', 'create', 8, 'tutors', NULL, '[]', '{\"id\":8,\"name\":\"NURFATIHAH ASYIRA\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone\":\"0176019723\",\"subject\":\"Bahasa Melayu\",\"availability\":\"1\",\"status\":0}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-01-11 23:22:44'),
(42, '65bfc19f-f2b2-47a2-8373-1632edd99d0b', 'create', 2, 'bookings', NULL, '[]', '{\"id\":2,\"student_name\":\"misha\",\"class_name\":\"Class A1\",\"date\":\"2026-01-12T09:38:02+08:00\",\"status\":\"1\"}', '{\"a_name\":\"Add\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/bookings\\/add\",\"slug\":1}', 1, NULL, '2026-01-12 09:38:10'),
(43, '568d2c19-c413-4cd4-b646-94cd0e94d8e6', 'update', 2, 'students', NULL, '{\"street_1\":\"\",\"street_2\":\"\",\"postcode\":0,\"city\":\"\",\"state\":\"\"}', '{\"street_1\":\"U10\\/ Pulau Angsa\",\"street_2\":\"Jalan Mokhtar Dahari\",\"postcode\":40100,\"city\":\"Shah Alam\",\"state\":\"Selangor\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/students\\/edit\\/2\",\"slug\":1}', 1, NULL, '2026-02-02 02:36:42'),
(44, '8166311b-a82b-4d7d-a91f-8a35f3740401', 'create', 5, 'teams', NULL, '[]', '{\"id\":5,\"subject_name\":\"Bahasa Melayu\",\"tutor_name\":\"Class A1\",\"start_time\":\"2026-02-03T03:00:58+08:00\",\"end_time\":\"2026-02-02T05:01:02+08:00\",\"total_student\":22}', '{\"a_name\":\"Add\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/teams\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 03:01:07'),
(45, 'aa032049-8925-4d5e-a8f1-cb9469629cf8', 'delete', 3, 'teams', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/teams\\/delete\\/3\",\"slug\":1}', 1, NULL, '2026-02-02 03:30:42'),
(46, '97f54c7b-8145-4c15-b647-4532c37234c0', 'create', 8, 'subjects', NULL, '[]', '{\"id\":8,\"level\":\"Primary 1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/subjects\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 04:34:22'),
(47, 'd8f639f5-0d2d-431e-9cca-570ea671b97c', 'create', 9, 'subjects', NULL, '[]', '{\"id\":9,\"level\":\"Primary 2\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/subjects\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 04:41:23'),
(48, '9f2ed3ed-3245-49ce-a901-c811a992841f', 'update', 8, 'subjects', NULL, '{\"subject_name\":\"\"}', '{\"subject_name\":\"bahasa melayu\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/subjects\\/edit\\/8\",\"slug\":1}', 1, NULL, '2026-02-02 04:42:53'),
(49, '1f1f2972-d803-4021-b2a6-8f998ad10ba9', 'create', 6, 'teams', NULL, '[]', '{\"id\":6,\"subject_name\":\"bahasa melayu\",\"tutor_name\":\"misha\",\"class_name\":\"A1\",\"level\":\"Primary 1\",\"start_time\":\"2026-02-03T04:44:26+08:00\",\"end_time\":\"2026-02-02T05:44:33+08:00\",\"total_student\":40,\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/teams\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 04:44:39'),
(50, 'fa78c021-e7b7-4dff-a0b8-452e59b57bc3', 'update', 5, 'teams', NULL, '{\"tutor_name\":\"Class A1\",\"class_name\":\"0\",\"level\":\"\"}', '{\"tutor_name\":\"misha\",\"class_name\":\"Class A1\",\"level\":\"Form 1\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/teams\\/edit\\/5\",\"slug\":1}', 1, NULL, '2026-02-02 04:45:00'),
(51, '5fabd6fa-0b98-43ad-8ee7-5e1fd1e43803', 'update', 4, 'teams', NULL, '{\"tutor_name\":\"Class A1\",\"class_name\":\"0\",\"level\":\"\"}', '{\"tutor_name\":\"syira\",\"class_name\":\"Class A1\",\"level\":\"Form 1\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/teams\\/edit\\/4\",\"slug\":1}', 1, NULL, '2026-02-02 04:45:31'),
(52, 'cf7642d9-54d9-4a9f-830c-0913ceb7d3fa', 'create', 3, 'bookings', NULL, '[]', '{\"id\":3,\"student_name\":\"misha\",\"class_name\":\"Class A1\",\"subject_name\":\"bahasa melayu\",\"tutor_name\":\"misha\",\"level\":\"Primary 1\",\"session\":\"1 FEBRUARY 2026\",\"date\":\"2026-02-10T04:48:28+08:00\",\"status\":\"Pending\"}', '{\"a_name\":\"Add\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/bookings\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 04:48:35'),
(53, 'df892c1b-b72a-45f2-847a-db0db4e0c024', 'update', 2, 'bookings', NULL, '{\"subject_name\":\"0\",\"tutor_name\":\"0\",\"level\":\"0\",\"session\":\"\"}', '{\"subject_name\":\"bahasa melayu\",\"tutor_name\":\"misha\",\"level\":\"Primary 1\",\"session\":\"1 FEBRUARY 2026\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/bookings\\/edit\\/2\",\"slug\":1}', 1, NULL, '2026-02-02 04:48:57'),
(54, '8d4ebbe7-dbc5-47ba-9ba8-07697a9be905', 'update', 1, 'bookings', NULL, '{\"subject_name\":\"0\",\"tutor_name\":\"0\",\"level\":\"0\",\"session\":\"\"}', '{\"subject_name\":\"bahasa melayu\",\"tutor_name\":\"misha\",\"level\":\"Form 1\",\"session\":\"1 FEBRUARY 2026\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/bookings\\/edit\\/1\",\"slug\":1}', 1, NULL, '2026-02-02 04:49:21'),
(55, 'd404b0a3-fbe2-49a2-998a-394a25dff0ca', 'create', 9, 'tutors', NULL, '[]', '{\"id\":9,\"email\":\"nurfatihahasyira@gmail.com\",\"phone\":\"0176019723\",\"availability\":\"1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 04:49:52'),
(56, '3e9c0672-b814-4677-9cb0-72b91dc6b2db', 'create', 4, 'bookings', NULL, '[]', '{\"id\":4,\"student_name\":\"misha\",\"class_name\":\"Class A1\",\"subject_name\":\"bahasa melayu\",\"tutor_name\":\"misha\",\"level\":\"Primary 1\",\"session\":\"1 FEBRUARY 2026\",\"date\":\"2026-02-11T04:53:30+08:00\",\"status\":\"Pending\"}', '{\"a_name\":\"Add\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 04:53:33'),
(57, 'd81685d1-9055-4d95-a698-f715e403af5f', 'update', 9, 'subjects', NULL, '{\"subject_name\":\"\"}', '{\"subject_name\":\"bahasa melayu\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Subjects\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/subjects\\/edit\\/9\",\"slug\":1}', 1, NULL, '2026-02-02 04:54:47'),
(58, '9cbc78e3-0442-4e32-b8b5-f90d2dc899f3', 'create', 3, 'students', NULL, '[]', '{\"id\":3,\"student_name\":\"misha\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone_number\":\"0176019723\",\"birth_date\":\"2026-02-03\",\"street_1\":\"U10\\/ Pulau Angsa\",\"street_2\":\"Jalan Mokhtar Dahari\",\"postcode\":35000,\"city\":\"Shah Alam\",\"state\":\"Selangor\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/students\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 04:56:54'),
(59, '29a70063-5445-4d9f-a2ab-4a49717ee6d4', 'update', 9, 'tutors', NULL, '{\"tutor_name\":\"\",\"subject_name\":\"\"}', '{\"tutor_name\":\"misha\",\"subject_name\":\"bahasa melayu\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/edit\\/9\",\"slug\":1}', 1, NULL, '2026-02-02 06:43:57'),
(60, '1ebc45ac-bbdd-442d-ae3b-3db3e51185dc', 'create', 10, 'tutors', NULL, '[]', '{\"id\":10,\"tutor_name\":\"misha\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone\":\"0176019723\",\"subject_name\":\"1\",\"availability\":\"1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 06:53:14'),
(61, '388d0f5a-990a-4099-9e9b-7a1df67625a1', 'create', 11, 'tutors', NULL, '[]', '{\"id\":11,\"tutor_name\":\"misha\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone\":\"0176019723\",\"subject_name\":\"bahasa melayu\",\"availability\":\"1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 06:54:24'),
(62, 'fbc4be51-480a-4a62-9874-d0092ab6801a', 'update', 3, 'students', NULL, '{\"student_name\":\"misha\",\"birth_date\":\"2026-02-03\"}', '{\"student_name\":\"NORMISHA SAFIAH\",\"birth_date\":\"2002-05-07\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/students\\/edit\\/3\",\"slug\":1}', 1, NULL, '2026-02-02 07:52:49'),
(63, 'be20d698-e7d7-46c0-8de7-6adf83927101', 'update', 3, 'students', NULL, '{\"email\":\"nurfatihahasyira@gmail.com\"}', '{\"email\":\"normisha@gmail.com\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/students\\/edit\\/3\",\"slug\":1}', 1, NULL, '2026-02-02 07:53:06'),
(64, '31d24867-723a-48d5-bf8f-c418564bc2c9', 'update', 3, 'students', NULL, '{\"phone_number\":\"0176019723\"}', '{\"phone_number\":\"0114563871\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/students\\/edit\\/3\",\"slug\":1}', 1, NULL, '2026-02-02 07:53:38'),
(65, '69a70df8-9d65-422a-a877-18267337dafa', 'update', 2, 'students', NULL, '{\"birth_date\":\"2025-12-29\"}', '{\"birth_date\":\"2000-11-01\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/students\\/edit\\/2\",\"slug\":1}', 1, NULL, '2026-02-02 07:54:07'),
(66, 'f9519bcb-bb79-45cf-827f-89eeaebadb85', 'create', 12, 'tutors', NULL, '[]', '{\"id\":12,\"tutor_name\":\"NURFATIHAH ASYIRA\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone\":\"0176019723\",\"subject_name\":\"bahasa melayu\",\"availability\":\"1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 08:00:38'),
(67, '2458ddfc-765e-45b2-a9f7-6fa85c9caa97', 'create', 13, 'tutors', NULL, '[]', '{\"id\":13,\"tutor_name\":\"NURFATIHAH ASYIRA\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone\":\"0176019723\",\"subject_name\":\"Computer Science\",\"availability\":\"1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 08:08:44'),
(68, 'bce9e61f-df3e-462b-a51b-4eaad588796d', 'update', 8, 'tutors', NULL, '{\"status\":0}', '{\"status\":1}', '{\"a_name\":\"Edit\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/edit\\/8\",\"slug\":1}', 1, NULL, '2026-02-02 08:13:34'),
(69, 'dab303f0-e335-4ef9-b8a1-7d8d7b2e3f33', 'delete', 8, 'tutors', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/delete\\/8\",\"slug\":1}', 1, NULL, '2026-02-02 08:17:19'),
(70, '10fed65a-00a6-4ff4-b336-61161eb7e929', 'delete', 9, 'tutors', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/delete\\/9\",\"slug\":1}', 1, NULL, '2026-02-02 08:17:22'),
(71, 'f14073f5-4de9-4e62-9116-cab57137b7a6', 'delete', 10, 'tutors', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/delete\\/10\",\"slug\":1}', 1, NULL, '2026-02-02 08:17:25'),
(72, '33c12327-832e-47ef-b4b0-0b8eb4b5dd48', 'delete', 11, 'tutors', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/delete\\/11\",\"slug\":1}', 1, NULL, '2026-02-02 08:17:27'),
(73, 'bb472b4d-0c12-481c-82cc-5f3e6a2be58e', 'delete', 12, 'tutors', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/delete\\/12\",\"slug\":1}', 1, NULL, '2026-02-02 08:17:29'),
(74, 'd831cb53-4cda-41cd-852b-7463d7778daf', 'delete', 13, 'tutors', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/delete\\/13\",\"slug\":1}', 1, NULL, '2026-02-02 08:17:31'),
(75, '9964456b-d5f6-4817-9e4f-96dfbff8704b', 'create', 14, 'tutors', NULL, '[]', '{\"id\":14,\"tutor_name\":\"NURFATIHAH ASYIRA\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone\":\"0176019723\",\"subject_name\":\"Chemistry\",\"availability\":\"1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 08:17:47'),
(76, '3fd0075d-cee6-48df-93a4-5b18e7710beb', 'create', 15, 'tutors', NULL, '[]', '{\"id\":15,\"tutor_name\":\"NURFATIHAH ASYIRA\",\"email\":\"nurfatihahasyira@gmail.com\",\"phone\":\"0176019723\",\"subject_name\":\"Computer Science\",\"availability\":\"1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 08:19:59'),
(77, '3d9f2e7c-d840-4627-b257-494cab6c63a6', 'update', 2, 'students', NULL, '{\"student_name\":\"NURFATIHAH ASYIRA\",\"email\":\"nurfatihahasyira@gmail.com\",\"street_1\":\"U10\\/ Pulau Angsa\",\"street_2\":\"Jalan Mokhtar Dahari\",\"postcode\":40100}', '{\"student_name\":\"NURUL NADIA BINTI NADHIR\",\"email\":\"nadia@gmail.com\",\"street_1\":\"No. 15, Jalan Kristal Tiga \",\"street_2\":\"7\\/76C, Seksyen 7\",\"postcode\":40000}', '{\"a_name\":\"Edit\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/students\\/edit\\/2\",\"slug\":1}', 1, NULL, '2026-02-02 11:14:09'),
(78, 'cc035379-e803-4357-af29-20a2001102c6', 'create', 16, 'tutors', NULL, '[]', '{\"id\":16,\"tutor_name\":\"NURUL IZZATI BINTI MD.NIZAM\",\"email\":\"izzati@vbest.com\",\"phone\":\"0123670665\",\"subject_name\":\"Bahasa Melayu\",\"availability\":\"1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 11:16:30'),
(79, '07018019-e844-425a-bb8c-fbdabeec2e64', 'update', 15, 'tutors', NULL, '{\"tutor_name\":\"NURFATIHAH ASYIRA\",\"email\":\"nurfatihahasyira@gmail.com\"}', '{\"tutor_name\":\"NURFATIHAH ASYIRA BINTI ABU KAHAR\",\"email\":\"nurfatihahasyira@vbest.com\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/edit\\/15\",\"slug\":1}', 1, NULL, '2026-02-02 11:17:07'),
(80, '4b025e28-71f9-4fdf-9e56-142eb85e1de7', 'update', 3, 'students', NULL, '{\"student_name\":\"NORMISHA SAFIAH\",\"email\":\"normisha@gmail.com\",\"street_1\":\"U10\\/ Pulau Angsa\",\"street_2\":\"Jalan Mokhtar Dahari\",\"postcode\":35000,\"city\":\"Shah Alam\"}', '{\"student_name\":\"FATIMAH ZAHRA BINTI AHMAD\",\"email\":\"fatimah@gmail.com\",\"street_1\":\"No. 12, Jalan Fauna 1\",\"street_2\":\"Symphony Hills, Cyber 9\",\"postcode\":63000,\"city\":\"Cyberjaya\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/students\\/edit\\/3\",\"slug\":1}', 1, NULL, '2026-02-02 11:32:27'),
(81, 'efdad5e3-98fe-41f4-b452-70e084f2ec07', 'update', 2, 'students', NULL, '{\"subject_name\":\"\",\"class_name\":\"\"}', '{\"subject_name\":\"Bahasa Melayu\",\"class_name\":\"Class A1\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/students\\/edit\\/2\",\"slug\":1}', 1, NULL, '2026-02-02 11:52:10'),
(82, 'ac04c25d-523b-4c76-b389-f2d33b560f3d', 'update', 3, 'students', NULL, '{\"subject_name\":\"\",\"class_name\":\"\"}', '{\"subject_name\":\"Computer Science\",\"class_name\":\"Class A2\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/students\\/edit\\/3\",\"slug\":1}', 1, NULL, '2026-02-02 11:52:50'),
(83, '5d67046b-a263-4bfa-b60a-50261ead7276', 'create', 4, 'students', NULL, '[]', '{\"id\":4,\"student_name\":\"SURAYA AMNA BINTI KHALID\",\"subject_name\":\"Mathematics\",\"class_name\":\"Class A3\",\"email\":\"suraya@gmail.com\",\"phone_number\":\"0114563871\",\"birth_date\":\"2012-07-17\",\"street_1\":\" Unit B-15-03, Cyberia SmartHomes\",\"street_2\":\"Jalan Cyberia 1, Cyber 11\",\"postcode\":63000,\"city\":\" Cyberjaya\",\"state\":\"Selangor\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/students\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 12:01:05'),
(84, 'dff463e7-d3f6-4ef2-b424-6b0ed0f851d3', 'create', 7, 'teams', NULL, '[]', '{\"id\":7,\"subject_name\":\"Bahasa Melayu\",\"tutor_name\":\"Pn. Norizzah\",\"class_name\":\"Class A1\",\"level\":\"Primary School\",\"start_time\":\"2026-02-07T12:33:18+08:00\",\"end_time\":\"2026-02-03T12:33:22+08:00\",\"total_student\":30,\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/teams\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 12:33:30'),
(85, '68992328-bed2-4168-ab28-f80a9d2c8e87', 'update', 4, 'teams', NULL, '{\"tutor_name\":\"syira\",\"class_name\":\"Class A1\",\"level\":\"Form 1\"}', '{\"tutor_name\":\"NURUL IZZATI BINTI MD.NIZAM\",\"class_name\":\"Class A2\",\"level\":\"Primary 3\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/teams\\/edit\\/4\",\"slug\":1}', 1, NULL, '2026-02-02 13:09:45'),
(86, '710701bb-5677-485b-b111-095dfc90621b', 'update', 5, 'teams', NULL, '{\"tutor_name\":\"misha\"}', '{\"tutor_name\":\"NORMISHA SAFIAH BINTI OMAR\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/teams\\/edit\\/5\",\"slug\":1}', 1, NULL, '2026-02-02 13:11:52'),
(87, '04e2a2d9-1e1d-4012-8c14-7264e79a53cd', 'update', 4, 'teams', NULL, '{\"total_student\":22}', '{\"total_student\":15}', '{\"a_name\":\"Edit\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/teams\\/edit\\/4\",\"slug\":1}', 1, NULL, '2026-02-02 13:12:20'),
(88, '3d3f1913-1d68-4367-8094-ff689aa497a0', 'update', 5, 'teams', NULL, '{\"total_student\":22}', '{\"total_student\":10}', '{\"a_name\":\"Edit\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/teams\\/edit\\/5\",\"slug\":1}', 1, NULL, '2026-02-02 13:12:36'),
(89, '9bea23a4-18c7-4f48-8ec0-34899d0c208f', 'update', 6, 'teams', NULL, '{\"subject_name\":\"bahasa melayu\",\"tutor_name\":\"misha\",\"class_name\":\"A1\",\"level\":\"Primary 1\",\"total_student\":40}', '{\"subject_name\":\"Mathematics\",\"tutor_name\":\"ADRIANNA BATRISYA BINTI ABD HALIM\",\"class_name\":\"Class A1\",\"level\":\"Primary 6\",\"total_student\":11}', '{\"a_name\":\"Edit\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/teams\\/edit\\/6\",\"slug\":1}', 1, NULL, '2026-02-02 13:13:23'),
(90, 'ba7e9716-870a-425f-802c-c9695aebb579', 'update', 7, 'teams', NULL, '{\"subject_name\":\"Bahasa Melayu\",\"tutor_name\":\"Pn. Norizzah\",\"class_name\":\"Class A1\",\"level\":\"Primary School\"}', '{\"subject_name\":\"Biology\",\"tutor_name\":\"NURFATIHAH ASYIRA BINTI ABU KAHAR\",\"class_name\":\"Class A5\",\"level\":\"Form 1\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/teams\\/edit\\/7\",\"slug\":1}', 1, NULL, '2026-02-02 13:13:58'),
(91, '00d9c71a-82b7-4493-8672-0ad62d073947', 'update', 7, 'teams', NULL, '{\"total_student\":30}', '{\"total_student\":10}', '{\"a_name\":\"Edit\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/teams\\/edit\\/7\",\"slug\":1}', 1, NULL, '2026-02-02 13:14:11'),
(92, 'd2a93152-eccc-4625-8686-ea906c4d571c', 'update', 1, 'bookings', NULL, '{\"student_name\":\"misha\",\"class_name\":\"Class A1\",\"subject_name\":\"bahasa melayu\",\"tutor_name\":\"misha\"}', '{\"student_name\":\"SURAYA AMNA BINTI KHALID\",\"class_name\":\"Class A3\",\"subject_name\":\"Matehmatics\",\"tutor_name\":\"NORMISHA SAFIAH BINTI OMAR\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/bookings\\/edit\\/1\",\"slug\":1}', 1, NULL, '2026-02-02 13:37:03'),
(93, '2c2a0fee-2ca5-4604-a9bc-7b9911a05c11', 'update', 2, 'bookings', NULL, '{\"student_name\":\"misha\",\"class_name\":\"Class A1\",\"subject_name\":\"bahasa melayu\",\"tutor_name\":\"misha\",\"level\":\"Primary 1\",\"session\":\"1 FEBRUARY 2026\"}', '{\"student_name\":\"FATIMAH ZAHRA BINTI AHMAD\",\"class_name\":\"Class A5\",\"subject_name\":\"Computer Science\",\"tutor_name\":\"ADRIANNA BATRISYA BINTI ABD HALIM\",\"level\":\"10\",\"session\":\"Feb 2026\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/edit\\/2\",\"slug\":1}', 1, NULL, '2026-02-02 13:44:36'),
(94, '7fec1f97-94a4-499c-8d97-309656adb3e5', 'update', 1, 'bookings', NULL, '{\"subject_name\":\"Matehmatics\",\"level\":\"Form 1\",\"session\":\"1 FEBRUARY 2026\"}', '{\"subject_name\":\"Mathematics\",\"level\":\"6\",\"session\":\"Feb 2026\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/edit\\/1\",\"slug\":1}', 1, NULL, '2026-02-02 13:45:05'),
(95, '8eddf02d-c550-4df0-a655-9ba94f410ca7', 'update', 3, 'bookings', NULL, '{\"student_name\":\"misha\",\"subject_name\":\"bahasa melayu\",\"tutor_name\":\"misha\",\"level\":\"Primary 1\",\"session\":\"1 FEBRUARY 2026\"}', '{\"student_name\":\"NURUL NADIA BINTI NADHIR\",\"subject_name\":\"Bahasa Melayu\",\"tutor_name\":\"NURUL IZZATI BINTI MD.NIZAM\",\"level\":\"6\",\"session\":\"Feb 2026\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/edit\\/3\",\"slug\":1}', 1, NULL, '2026-02-02 13:46:18'),
(96, 'cfeaa186-53ae-4665-8d3e-1e38d804004d', 'delete', 4, 'bookings', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/delete\\/4\",\"slug\":1}', 1, NULL, '2026-02-02 13:46:37'),
(97, 'dec92575-6009-499e-94ad-59b9c59e1e10', 'delete', 3, 'bookings', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/delete\\/3\",\"slug\":1}', 1, NULL, '2026-02-02 13:47:17'),
(98, 'dfb85a24-3620-403a-83cc-b251a7dcd67c', 'update', 1, 'bookings', NULL, '{\"level\":\"6\"}', '{\"level\":\"5\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/bookings\\/edit\\/1\",\"slug\":1}', 1, NULL, '2026-02-02 13:52:19'),
(99, 'b53c22a8-c1ab-4977-b219-0147b6ab7984', 'update', 1, 'bookings', NULL, '{\"level\":\"5\"}', '{\"level\":\"0\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/edit\\/1\",\"slug\":1}', 1, NULL, '2026-02-02 13:53:39'),
(100, '207e8255-15b5-457a-b823-64117a54326a', 'update', 1, 'bookings', NULL, '{\"level\":\"0\"}', '{\"level\":\"6\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/edit\\/1\",\"slug\":1}', 1, NULL, '2026-02-02 13:54:45'),
(101, 'bf8762cc-0909-4a05-95df-442765197042', 'update', 1, 'bookings', NULL, '{\"class_name\":\"Class A3\",\"tutor_name\":\"NORMISHA SAFIAH BINTI OMAR\",\"level\":\"6\"}', '{\"class_name\":\"Class A2\",\"tutor_name\":\"0\",\"level\":\"5\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/edit\\/1\",\"slug\":1}', 1, NULL, '2026-02-02 14:11:27'),
(102, 'e63c1157-2763-4b48-ada5-8a5ebd400f4f', 'create', 5, 'bookings', NULL, '[]', '{\"id\":5,\"student_name\":\"SURAYA AMNA BINTI KHALID\",\"class_name\":\"Class A1\",\"subject_name\":\"Bahasa Melayu\",\"tutor_name\":\"NORMISHA SAFIAH BINTI OMAR\",\"level\":\"0\",\"session\":\"Feb 2026\",\"date\":\"2026-02-04T14:13:55+08:00\",\"status\":\"Pending\"}', '{\"a_name\":\"Add\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 14:13:58'),
(103, 'dba95158-1b3c-4abb-bdfd-efcca55f9a56', 'delete', 1, 'bookings', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/delete\\/1\",\"slug\":1}', 1, NULL, '2026-02-02 14:23:36'),
(104, '694cef2b-e050-46ee-96bf-7683b387b5dd', 'delete', 2, 'bookings', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/delete\\/2\",\"slug\":1}', 1, NULL, '2026-02-02 14:23:38'),
(105, '53331fa2-d729-46e8-9156-8ee23d234c1b', 'delete', 5, 'bookings', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/delete\\/5\",\"slug\":1}', 1, NULL, '2026-02-02 14:23:39'),
(106, '9a0404b7-0dd8-4b24-8106-af47e69df43b', 'create', 6, 'bookings', NULL, '[]', '{\"id\":6,\"student_name\":\"SURAYA AMNA BINTI KHALID\",\"class_name\":\"Class A1\",\"subject_name\":\"English\",\"tutor_name\":\"0\",\"level\":\"0\",\"session\":\"Feb 2026\",\"date\":\"2026-02-02T16:23:50+08:00\",\"status\":\"1\"}', '{\"a_name\":\"Add\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 14:23:57'),
(107, 'f0a5f4ba-3e0d-4dc7-b18b-6c55660854ed', 'create', 7, 'bookings', NULL, '[]', '{\"id\":7,\"student_name\":\"SURAYA AMNA BINTI KHALID\",\"class_name\":\"Class A2\",\"subject_name\":\"Bahasa Melayu\",\"tutor_name\":\"0\",\"level\":\"0\",\"session\":\"Feb 2026\",\"date\":\"2026-02-02T14:29:58+08:00\",\"status\":\"1\"}', '{\"a_name\":\"Add\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 14:29:07'),
(108, 'a4656698-bb32-439e-bbc8-e672e9ea945f', 'create', 8, 'bookings', NULL, '[]', '{\"id\":8,\"student_name\":\"SURAYA AMNA BINTI KHALID\",\"class_name\":\"Class A1\",\"subject_name\":\"Bahasa Melayu\",\"tutor_name\":\"NORMISHA SAFIAH BINTI OMAR\",\"level\":\"0\",\"session\":\"Feb 2026\",\"date\":\"2026-02-04T14:37:53+08:00\",\"status\":\"Pending\"}', '{\"a_name\":\"Add\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 14:37:55'),
(109, '46493e00-06a3-4c26-a103-76f2ad296291', 'create', 9, 'bookings', NULL, '[]', '{\"id\":9,\"student_name\":\"SURAYA AMNA BINTI KHALID\",\"class_name\":\"Class A1\",\"subject_name\":\"Bahasa Melayu\",\"tutor_name\":\"NORMISHA SAFIAH BINTI OMAR\",\"level\":\"1\",\"session\":\"Feb 2026\",\"date\":\"2026-02-02T16:51:54+08:00\",\"status\":\"Pending\"}', '{\"a_name\":\"Add\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/bookings\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 14:51:57'),
(110, '8a8366fc-6ecb-4170-9bcd-140fec72c633', 'delete', 6, 'bookings', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/delete\\/6\",\"slug\":1}', 1, NULL, '2026-02-02 14:56:49'),
(111, 'bd51bb47-c511-4caf-b241-7d611560e146', 'delete', 7, 'bookings', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/delete\\/7\",\"slug\":1}', 1, NULL, '2026-02-02 14:56:51'),
(112, '0655acc8-ef9d-42c4-abed-9ef9f97f8b31', 'delete', 8, 'bookings', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/delete\\/8\",\"slug\":1}', 1, NULL, '2026-02-02 14:58:02'),
(113, 'c2a661ac-497b-46f3-aa31-869beffdf199', 'delete', 9, 'bookings', NULL, NULL, NULL, '{\"a_name\":\"Delete\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/delete\\/9\",\"slug\":1}', 1, NULL, '2026-02-02 14:58:04'),
(114, '96d2ddeb-113e-4034-a49f-7e4cad8f9dcb', 'create', 10, 'bookings', NULL, '[]', '{\"id\":10,\"student_name\":\"SURAYA AMNA BINTI KHALID\",\"class_name\":\"Class A1\",\"subject_name\":\"Bahasa Melayu\",\"tutor_name\":\"NORMISHA SAFIAH BINTI OMAR\",\"level\":\"0\",\"session\":\"Feb 2026\",\"date\":\"2026-02-04T14:58:19+08:00\",\"status\":\"Pending\"}', '{\"a_name\":\"Add\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 14:58:23'),
(115, '82f9ea2e-2c95-4e68-acea-d95a89ece4ba', 'create', 11, 'bookings', NULL, '[]', '{\"id\":11,\"student_name\":\"NURUL NADIA BINTI NADHIR\",\"class_name\":\"Class A1\",\"subject_name\":\"Bahasa Melayu\",\"tutor_name\":\"NURUL IZZATI BINTI MD.NIZAM\",\"level\":\"5\",\"session\":\"Feb 2026\",\"date\":\"2026-01-22T16:09:29+08:00\",\"status\":\"Pending\"}', '{\"a_name\":\"Add\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 16:09:41'),
(116, 'd8fb4a79-11f1-4bd2-b474-bbe94bb3f331', 'update', 10, 'bookings', NULL, '{\"class_name\":\"Class A1\"}', '{\"class_name\":\"Class A3\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/bookings\\/edit\\/10\",\"slug\":1}', 1, NULL, '2026-02-02 17:44:33'),
(117, '41b81a57-6bf9-4caf-aaee-345cc4061160', 'update', 10, 'bookings', NULL, '{\"subject_name\":\"Bahasa Melayu\"}', '{\"subject_name\":\"Mathematics\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/bookings\\/edit\\/10\",\"slug\":1}', 1, NULL, '2026-02-02 17:45:05'),
(118, '47fb9173-c275-4ef5-ad59-bc107f653dfe', 'create', 12, 'bookings', NULL, '[]', '{\"id\":12,\"student_name\":\"FATIMAH ZAHRA BINTI AHMAD\",\"class_name\":\"Class A2\",\"subject_name\":\"Computer Science\",\"tutor_name\":\"ADRIANNA BATRISYA BINTI ABD HALIM\",\"level\":\"10\",\"session\":\"Feb 2026\",\"date\":\"2026-01-06T00:00:00+08:00\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/bookings\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 17:51:17'),
(119, '5efffda1-df0d-46ba-8616-9add99dafecf', 'create', 13, 'bookings', NULL, '[]', '{\"id\":13,\"student_name\":\"AMMAR NABIL BINTI HALIM\",\"class_name\":\"Class A5\",\"subject_name\":\"Additional Mathematics\",\"tutor_name\":\"NURFATIHAH ASYIRA BINTI ABU KAHAR\",\"level\":\"10\",\"session\":\"Feb 2026\",\"date\":\"2026-01-11T00:00:00+08:00\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Bookings\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/bookings\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 17:54:09'),
(120, 'ed2f7f46-5e04-4afb-be8c-c8409eeeae8b', 'create', 5, 'students', NULL, '[]', '{\"id\":5,\"student_name\":\"AMMAR NABIL BINTI HALIM\",\"subject_name\":\"Mathematics\",\"class_name\":\"Class A5\",\"email\":\"ammar@gmail.com\",\"phone_number\":\"0135558734\",\"birth_date\":\"2009-06-02\",\"street_1\":\"U10\\/ Pulau Angsa\",\"street_2\":\"Jalan Mokhtar Dahari\",\"postcode\":35000,\"city\":\"Shah Alam\",\"state\":\"Selangor\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/students\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 17:57:37'),
(121, '9099788f-eb10-4471-86c5-4acb5077874e', 'create', 17, 'tutors', NULL, '[]', '{\"id\":17,\"tutor_name\":\"ADRIANNA BATRISYA BINTI ABD HALIM\",\"email\":\"adrianna@vbest.com\",\"phone\":\"0142842366\",\"subject_name\":\"Mathematics\",\"availability\":\"1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 17:58:41'),
(122, 'e6e7ccdd-9eb4-4b30-b7a2-7d0465ea8fed', 'update', 17, 'tutors', NULL, '{\"subject_name\":\"Mathematics\"}', '{\"subject_name\":\"Computer Science\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/edit\\/17\",\"slug\":1}', 1, NULL, '2026-02-02 17:59:36'),
(123, '1a5ed811-0c6b-43f7-816f-a88e4ba89af6', 'update', 5, 'students', NULL, '{\"subject_name\":\"Mathematics\"}', '{\"subject_name\":\"Additional Mathematics\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Students\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/students\\/edit\\/5\",\"slug\":1}', 1, NULL, '2026-02-02 17:59:57'),
(124, '38c55abe-0460-48cb-9255-efc40b76d31d', 'update', 15, 'tutors', NULL, '{\"subject_name\":\"Computer Science\"}', '{\"subject_name\":\"Additional Mathematics\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/edit\\/15\",\"slug\":1}', 1, NULL, '2026-02-02 18:00:14'),
(125, '82af29f0-a7cc-45e0-ac19-d712da9a16d4', 'create', 18, 'tutors', NULL, '[]', '{\"id\":18,\"tutor_name\":\"NORMISHA SAFIAH BINTI OMAR\",\"email\":\"misyaa@vbest.com\",\"phone\":\"0136728773\",\"subject_name\":\"Mathematics\",\"availability\":\"1\",\"status\":1}', '{\"a_name\":\"Add\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/add\",\"slug\":1}', 1, NULL, '2026-02-02 18:00:53'),
(126, 'eda6b254-b7cf-4e0e-85c7-336242fa758f', 'update', 15, 'tutors', NULL, '{\"email\":\"nurfatihahasyira@vbest.com\"}', '{\"email\":\"asyira@vbest.com\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Tutors\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/admin\\/tutors\\/edit\\/15\",\"slug\":1}', 1, NULL, '2026-02-02 18:01:11'),
(127, 'f2afae12-fc10-4dd9-bf21-28af75a40d21', 'update', 7, 'teams', NULL, '{\"subject_name\":\"Biology\"}', '{\"subject_name\":\"Additional Mathematics\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/teams\\/edit\\/7\",\"slug\":1}', 1, NULL, '2026-02-02 18:01:30'),
(128, '4537857b-0d9d-46c2-a2bc-f720176980cb', 'update', 5, 'teams', NULL, '{\"subject_name\":\"Bahasa Melayu\"}', '{\"subject_name\":\"Mathematics\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/teams\\/edit\\/5\",\"slug\":1}', 1, NULL, '2026-02-02 18:01:37'),
(129, 'e1e3526a-2675-41c8-a46d-902fb6e9d863', 'update', 6, 'teams', NULL, '{\"subject_name\":\"Mathematics\"}', '{\"subject_name\":\"Computer Science\"}', '{\"a_name\":\"Edit\",\"c_name\":\"Teams\",\"ip\":\"::1\",\"url\":\"http:\\/\\/localhost\\/tuitionbooking\\/teams\\/edit\\/6\",\"slug\":1}', 1, NULL, '2026-02-02 18:01:44');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int NOT NULL,
  `student_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `class_name` varchar(50) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `tutor_name` varchar(100) NOT NULL,
  `level` varchar(50) NOT NULL,
  `session` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `status` int NOT NULL DEFAULT '1',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `student_name`, `class_name`, `subject_name`, `tutor_name`, `level`, `session`, `date`, `status`, `created`, `modified`) VALUES
(10, 'SURAYA AMNA BINTI KHALID', 'Class A3', 'Mathematics', 'NORMISHA SAFIAH BINTI OMAR', '0', 'Feb 2026', '2026-02-04 14:58:19', 1, '2026-02-02 14:58:23', '2026-02-02 17:45:05'),
(11, 'NURUL NADIA BINTI NADHIR', 'Class A1', 'Bahasa Melayu', 'NURUL IZZATI BINTI MD.NIZAM', '5', 'Feb 2026', '2026-01-22 16:09:29', 1, '2026-02-02 16:09:41', '2026-02-02 16:09:41'),
(12, 'FATIMAH ZAHRA BINTI AHMAD', 'Class A2', 'Computer Science', 'ADRIANNA BATRISYA BINTI ABD HALIM', '10', 'Feb 2026', '2026-01-06 00:00:00', 1, '2026-02-02 17:51:17', '2026-02-02 17:51:17'),
(13, 'AMMAR NABIL BINTI HALIM', 'Class A5', 'Additional Mathematics', 'NURFATIHAH ASYIRA BINTI ABU KAHAR', '10', 'Feb 2026', '2026-01-11 00:00:00', 1, '2026-02-02 17:54:09', '2026-02-02 17:54:09');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `ticket` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `notes` text NOT NULL,
  `note_admin` text,
  `ip` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT '0',
  `is_replied` tinyint(1) NOT NULL,
  `respond_date_time` datetime DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int NOT NULL,
  `category` varchar(100) NOT NULL,
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `status` int NOT NULL DEFAULT '1',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `category`, `question`, `answer`, `slug`, `status`, `created`, `modified`) VALUES
(1, 'General', 'General Questions 1', 'General Answer 1', 'General-Questions-1', 1, '2022-11-13 15:41:26', '2022-11-13 16:31:14'),
(2, 'Account', 'Account Questions 1', 'Account Answer 1', 'Account-Questions-1', 1, '2022-11-13 15:43:15', '2022-11-13 15:43:15'),
(3, 'Other', 'Other Questions 1', 'Other Answer 1', 'Other-Questions-1', 1, '2022-11-13 15:43:34', '2022-11-13 15:43:34'),
(6, 'General', 'General Questions 2', 'General Answer 2', 'General-Questions-2', 0, '2022-11-13 16:54:25', '2024-06-25 13:03:08');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int UNSIGNED NOT NULL,
  `parent_id` int DEFAULT NULL,
  `lft` int DEFAULT NULL,
  `rght` int DEFAULT NULL,
  `level` int DEFAULT '0',
  `icon` varchar(255) DEFAULT NULL,
  `controller` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `target` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `prefix` varchar(255) DEFAULT NULL,
  `auth` tinyint(1) DEFAULT NULL,
  `admin` tinyint(1) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `disabled` tinyint(1) DEFAULT NULL,
  `divider_before` tinyint(1) DEFAULT '0',
  `parent_separator` tinyint(1) DEFAULT NULL,
  `division` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `parent_id`, `lft`, `rght`, `level`, `icon`, `controller`, `action`, `target`, `name`, `url`, `prefix`, `auth`, `admin`, `active`, `disabled`, `divider_before`, `parent_separator`, `division`) VALUES
(1, NULL, 1, 2, 0, '<i class=\"fa-solid fa-code\"></i>', 'Dashboards', 'Index', NULL, 'Dashboard', '', '', 1, 0, 1, 0, 0, 0, 0),
(2, NULL, 3, 4, 0, '<i class=\"fa-regular fa-circle-question\"></i>', 'Faqs', '', NULL, 'FAQs', '', '', 0, 0, 1, 0, 0, NULL, 0),
(3, NULL, 5, 6, 0, '<i class=\"fa-regular fa-message\"></i>', 'Contacts', 'Add', NULL, 'Contact Us', '', '', 0, 0, 1, NULL, 0, NULL, 0),
(4, NULL, 7, 14, 0, '<i class=\"fa-solid fa-circle-info\"></i>', 'Pages', 'manual', NULL, 'Documentation', '', '', 0, 0, 1, 0, 0, 1, 0),
(5, NULL, 15, 16, 0, '', '', '', NULL, 'Administrator', '', NULL, 0, 1, 1, NULL, 0, NULL, 1),
(6, NULL, 17, 18, 0, '<i class=\"fa-solid fa-gear\"></i>', 'Settings', 'Update', 'recrud', 'System Configuration', '', 'Admin', 1, 1, 1, NULL, 0, 0, 0),
(7, NULL, 19, 20, 0, '<i class=\"fa-solid fa-users-viewfinder\"></i>', 'Users', 'Index', NULL, 'User Management', '', 'Admin', 1, 1, 1, NULL, 0, NULL, 0),
(8, NULL, 21, 22, 0, '<i class=\"fa-solid fa-bars\"></i>', 'Menus', 'Index', NULL, 'Menu Management', '', 'Admin', 1, 1, 1, NULL, 0, 0, 0),
(9, NULL, 23, 24, 0, '<i class=\"menu-icon fa-solid fa-list-check\"></i>', 'Todos', 'Index', NULL, 'Todo List', '', 'Admin', 1, 1, 1, NULL, 0, NULL, 0),
(10, NULL, 25, 26, 0, '<i class=\"fa-regular fa-message\"></i>', 'Contacts', 'Index', NULL, 'Contact', '', 'Admin', 1, 1, 1, NULL, 0, NULL, 0),
(11, NULL, 27, 28, 0, '<i class=\"menu-icon fa-solid fa-timeline\"></i>', 'AuditLogs', 'Index', NULL, 'Audit Trail', '', 'Admin', 1, 1, 1, NULL, 0, NULL, 0),
(12, NULL, 29, 30, 0, '<i class=\"menu-icon fa-regular fa-circle-question\"></i>', 'Faqs', 'Index', NULL, 'FAQs', '', 'Admin', 1, 1, 1, NULL, 0, 0, 0),
(13, 4, 10, 11, 1, '<i class=\"fa-solid fa-code\"></i>', '', '', NULL, 'Code The Pixel', 'https://codethepixel.com/', '', 0, 0, 1, NULL, 0, 0, 0),
(14, 4, 8, 9, 1, '<i class=\"fa-regular fa-file-code\"></i>', 'Pages', 'manual', NULL, 'User Manual', '', '', 0, 0, 1, NULL, 0, 0, 0),
(15, 4, 12, 13, 1, '<i class=\"fa-brands fa-github\"></i>', '', '', NULL, 'Re-CRUD Github', 'https://github.com/Asyraf-wa/recrud', '', 0, 0, 1, NULL, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `phinxlog`
--

CREATE TABLE `phinxlog` (
  `version` bigint NOT NULL,
  `migration_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `phinxlog`
--

INSERT INTO `phinxlog` (`version`, `migration_name`, `start_time`, `end_time`, `breakpoint`) VALUES
(20241029053753, 'Initial', '2026-01-10 14:38:41', '2026-01-10 14:38:41', 0);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` char(36) NOT NULL,
  `system_name` varchar(255) NOT NULL,
  `system_abbr` varchar(255) NOT NULL,
  `system_slogan` varchar(255) NOT NULL,
  `organization_name` varchar(255) NOT NULL,
  `domain_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `notification_email` varchar(50) NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keyword` varchar(255) NOT NULL,
  `meta_subject` varchar(255) NOT NULL,
  `meta_copyright` varchar(255) NOT NULL,
  `meta_desc` varchar(255) NOT NULL,
  `timezone` varchar(100) NOT NULL,
  `author` varchar(255) NOT NULL,
  `site_status` tinyint(1) NOT NULL,
  `user_reg` tinyint(1) NOT NULL,
  `config_2` tinyint(1) NOT NULL,
  `config_3` tinyint(1) NOT NULL,
  `version` varchar(255) NOT NULL,
  `private_key_from_recaptcha` varchar(255) DEFAULT NULL,
  `public_key_from_recaptcha` varchar(255) DEFAULT NULL,
  `banned_username` text,
  `telegram_bot_token` varchar(255) DEFAULT NULL,
  `telegram_chatid` varchar(255) DEFAULT NULL,
  `hcaptcha_sitekey` varchar(255) DEFAULT NULL,
  `hcaptcha_secretkey` varchar(255) DEFAULT NULL,
  `notification` text NOT NULL,
  `notification_status` tinyint(1) NOT NULL,
  `notification_date` date DEFAULT NULL,
  `ribbon_title` varchar(20) NOT NULL,
  `ribbon_link` varchar(255) NOT NULL,
  `ribbon_status` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `system_name`, `system_abbr`, `system_slogan`, `organization_name`, `domain_name`, `email`, `notification_email`, `meta_title`, `meta_keyword`, `meta_subject`, `meta_copyright`, `meta_desc`, `timezone`, `author`, `site_status`, `user_reg`, `config_2`, `config_3`, `version`, `private_key_from_recaptcha`, `public_key_from_recaptcha`, `banned_username`, `telegram_bot_token`, `telegram_chatid`, `hcaptcha_sitekey`, `hcaptcha_secretkey`, `notification`, `notification_status`, `notification_date`, `ribbon_title`, `ribbon_link`, `ribbon_status`, `created`, `modified`) VALUES
('recrud', 'VBest Tuition Booking System', 'vbesttuition', 'Code The Experiences', 'Code The Pixel Inc.', 'codethepixel.com', 'noreply@codethepixel.com', 'noreply@codethepixel.com', 'Re-CRUD', 'Re-CRUD, CakePHP, Learning, CRUD', 'Re-CRUD', 'Re-CRUD', 'Re-CRUD', 'Asia/Kuala_Lumpur', 'Re-CRUD', 0, 0, 0, 0, '1.1', '', '', NULL, '', '', '', '', '<p><strong>Server maintenance</strong> is scheduled to be executed on Jan 1, 2023, from 1.00 am to 4.00 am. An intermittent connection is expected during the server maintenance period.</p>', 0, '2022-11-07', 'Code The Pixel', 'https://codethepixel.com', 0, '2020-04-08 20:56:04', '2026-01-11 18:34:42');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int NOT NULL,
  `student_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `class_name` varchar(50) NOT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `phone_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `birth_date` date NOT NULL,
  `street_1` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `street_2` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `postcode` int NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `status` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `student_name`, `subject_name`, `class_name`, `email`, `phone_number`, `birth_date`, `street_1`, `street_2`, `postcode`, `created`, `modified`, `city`, `state`, `status`) VALUES
(2, 'NURUL NADIA BINTI NADHIR', 'Bahasa Melayu', 'Class A1', 'nadia@gmail.com', '0176019723', '2000-11-01', 'No. 15, Jalan Kristal Tiga ', '7/76C, Seksyen 7', 40000, '2026-01-11 22:29:21', '2026-02-02 11:52:10', 'Shah Alam', 'Selangor', 1),
(3, 'FATIMAH ZAHRA BINTI AHMAD', 'Computer Science', 'Class A2', 'fatimah@gmail.com', '0114563871', '2002-05-07', 'No. 12, Jalan Fauna 1', 'Symphony Hills, Cyber 9', 63000, '2026-02-02 04:56:54', '2026-02-02 11:52:50', 'Cyberjaya', 'Selangor', 1),
(4, 'SURAYA AMNA BINTI KHALID', 'Mathematics', 'Class A3', 'suraya@gmail.com', '0114563871', '2012-07-17', ' Unit B-15-03, Cyberia SmartHomes', 'Jalan Cyberia 1, Cyber 11', 63000, '2026-02-02 12:01:05', '2026-02-02 12:01:05', ' Cyberjaya', 'Selangor', 1),
(5, 'AMMAR NABIL BINTI HALIM', 'Additional Mathematics', 'Class A5', 'ammar@gmail.com', '0135558734', '2009-06-02', 'U10/ Pulau Angsa', 'Jalan Mokhtar Dahari', 35000, '2026-02-02 17:57:37', '2026-02-02 17:59:57', 'Shah Alam', 'Selangor', 1);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int NOT NULL,
  `subject_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `level` varchar(50) NOT NULL,
  `status` int NOT NULL DEFAULT '1',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `subject_name`, `level`, `status`, `created`, `modified`) VALUES
(7, 'English', 'Primary 1', 1, '2026-01-11 22:42:06', '2026-02-02 04:34:12'),
(8, 'bahasa melayu', 'Primary 1', 1, '2026-02-02 04:34:22', '2026-02-02 04:42:53'),
(9, 'bahasa melayu', 'Primary 2', 1, '2026-02-02 04:41:23', '2026-02-02 04:54:47');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` int NOT NULL,
  `subject_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `tutor_name` varchar(100) NOT NULL,
  `class_name` varchar(50) NOT NULL,
  `level` varchar(100) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `total_student` int NOT NULL,
  `status` int NOT NULL DEFAULT '1',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `subject_name`, `tutor_name`, `class_name`, `level`, `start_time`, `end_time`, `total_student`, `status`, `created`, `modified`) VALUES
(4, 'Bahasa Melayu', 'NURUL IZZATI BINTI MD.NIZAM', 'Class A2', 'Primary 3', '2025-12-30 22:30:30', '2026-01-11 22:30:33', 15, 1, '2026-01-11 22:30:41', '2026-02-02 13:12:20'),
(5, 'Mathematics', 'NORMISHA SAFIAH BINTI OMAR', 'Class A1', 'Form 1', '2026-02-03 03:00:58', '2026-02-02 05:01:02', 10, 1, '2026-02-02 03:01:07', '2026-02-02 18:01:37'),
(6, 'Computer Science', 'ADRIANNA BATRISYA BINTI ABD HALIM', 'Class A1', 'Primary 6', '2026-02-03 04:44:26', '2026-02-02 05:44:33', 11, 1, '2026-02-02 04:44:39', '2026-02-02 18:01:44'),
(7, 'Additional Mathematics', 'NURFATIHAH ASYIRA BINTI ABU KAHAR', 'Class A5', 'Form 1', '2026-02-07 12:33:18', '2026-02-03 12:33:22', 10, 1, '2026-02-02 12:33:30', '2026-02-02 18:01:30');

-- --------------------------------------------------------

--
-- Table structure for table `todos`
--

CREATE TABLE `todos` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `urgency` varchar(255) NOT NULL COMMENT 'high, medium, low',
  `task` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `note` text NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Pending' COMMENT 'Pending, In Progress, Completed, Canceled',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `todos`
--

INSERT INTO `todos` (`id`, `user_id`, `urgency`, `task`, `description`, `note`, `status`, `created`, `modified`) VALUES
('a02daac9-27e3-49ea-8090-927e60f9e255', '1', 'High', 'Student Team Updated', '<p>task 4 desc</p>', '<p>task 4 desc</p>', 'In Progress', '2024-05-31 13:48:26', '2026-01-12 08:58:46'),
('a8618f9e-a3f7-4e7a-8a3f-05a5323cd5af', '1', 'High', 'task 1', '<p>task 1 desc</p>', '<p>task 1 desc</p>', 'Completed', '2024-05-31 13:45:22', '2024-05-31 13:45:40'),
('c892f026-c6f8-4353-82c2-75f49c0f5d6b', '1', 'High', 'Task 3 - Booking Approval ', '<p>Review and approve student booking for Math class.</p>', '<p>Booking Approval</p>', 'Pending', '2024-05-31 13:48:06', '2026-01-11 17:32:58'),
('eda46e51-555a-4309-a28b-d0835bf4f4b2', '1', 'Low', 'task 2', '<p>task 2 desc</p>', '<p>task 2 desc</p>', 'Canceled', '2024-05-31 13:46:12', '2024-05-31 13:46:24');

-- --------------------------------------------------------

--
-- Table structure for table `tutors`
--

CREATE TABLE `tutors` (
  `id` int NOT NULL,
  `tutor_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `subject_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `availability` varchar(50) NOT NULL,
  `status` int NOT NULL DEFAULT '1',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tutors`
--

INSERT INTO `tutors` (`id`, `tutor_name`, `email`, `phone`, `subject_name`, `availability`, `status`, `created`, `modified`) VALUES
(15, 'NURFATIHAH ASYIRA BINTI ABU KAHAR', 'asyira@vbest.com', '0176019723', 'Additional Mathematics', '1', 1, '2026-02-02 08:19:59', '2026-02-02 18:01:11'),
(16, 'NURUL IZZATI BINTI MD.NIZAM', 'izzati@vbest.com', '0123670665', 'Bahasa Melayu', '1', 1, '2026-02-02 11:16:30', '2026-02-02 11:16:30'),
(17, 'ADRIANNA BATRISYA BINTI ABD HALIM', 'adrianna@vbest.com', '0142842366', 'Computer Science', '1', 1, '2026-02-02 17:58:41', '2026-02-02 17:59:36'),
(18, 'NORMISHA SAFIAH BINTI OMAR', 'misyaa@vbest.com', '0136728773', 'Mathematics', '1', 1, '2026-02-02 18:00:53', '2026-02-02 18:00:53');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `user_group_id` int DEFAULT '3',
  `fullname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `avatar_dir` varchar(255) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `token_created_at` datetime NOT NULL,
  `status` varchar(1) NOT NULL DEFAULT '0' COMMENT '	is_active',
  `is_email_verified` int NOT NULL DEFAULT '0',
  `last_login` datetime DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` int DEFAULT NULL COMMENT 'user_id',
  `modified_by` int DEFAULT NULL COMMENT 'user_id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_group_id`, `fullname`, `password`, `email`, `avatar`, `avatar_dir`, `token`, `token_created_at`, `status`, `is_email_verified`, `last_login`, `ip_address`, `slug`, `created`, `modified`, `created_by`, `modified_by`) VALUES
(1, 1, 'Administrator', '$2y$10$OrUKHzNQUic6dFqSuG9QBeDzMbbwPz1BQXKgBKPcQyMTNdv3Z22xe', 'admin@localhost.com', '', '', NULL, '2024-07-10 20:30:04', '1', 1, '2026-01-29 00:31:46', '::1', 'Administrator', '2022-10-26 02:54:19', '2024-07-08 21:08:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` text,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`id`, `name`, `description`, `created`, `modified`) VALUES
(1, 'Admin', 'Admninistrator', '2021-01-23 13:21:29', '2021-01-23 13:21:29'),
(2, 'Mod', 'Moderator', '2021-01-23 13:21:29', '2021-01-23 13:21:29'),
(3, 'User', 'Normal User', '2021-01-23 13:21:29', '2021-01-23 13:21:29');

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

CREATE TABLE `user_logs` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `useragent` varchar(256) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `referrer` varchar(255) DEFAULT NULL,
  `status` int DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_logs`
--

INSERT INTO `user_logs` (`id`, `user_id`, `action`, `useragent`, `os`, `ip`, `host`, `referrer`, `status`, `created`, `modified`) VALUES
(1, 1, 'Login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'build 22000 (Windows 11)', '::1', 'DESKTOP-JMR591K', NULL, 1, '2026-01-10 22:40:41', '2026-01-10 22:40:41'),
(2, 1, 'Login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'build 22000 (Windows 11)', '::1', 'DESKTOP-JMR591K', NULL, 1, '2026-01-11 12:10:52', '2026-01-11 12:10:52'),
(3, 1, 'Login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'build 22000 (Windows 11)', '::1', 'DESKTOP-JMR591K', NULL, 1, '2026-01-12 08:45:56', '2026-01-12 08:45:56'),
(4, 1, 'Login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'build 22000 (Windows 11)', '::1', 'DESKTOP-JMR591K', NULL, 1, '2026-01-29 00:31:46', '2026-01-29 00:31:46'),
(5, 1, 'Logout', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'build 22000 (Windows 11)', '::1', 'DESKTOP-JMR591K', 'http://localhost/tuitionbooking/', 1, '2026-02-02 22:21:33', '2026-02-02 22:21:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transaction` (`transaction`),
  ADD KEY `type` (`type`),
  ADD KEY `primary_key` (`primary_key`),
  ADD KEY `source` (`source`),
  ADD KEY `parent_source` (`parent_source`),
  ADD KEY `created` (`created`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lft` (`lft`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `phinxlog`
--
ALTER TABLE `phinxlog`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `todos`
--
ALTER TABLE `todos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tutors`
--
ALTER TABLE `tutors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tutors`
--
ALTER TABLE `tutors`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_logs`
--
ALTER TABLE `user_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
